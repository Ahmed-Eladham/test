import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { AreaChart, BarChart } from "@/components/ui/chart"
import { MapPin, Droplets, Cloud, Sprout, Sun, Leaf, AlertTriangle } from 'lucide-react'

export default function Dashboard() {
  const [location, setLocation] = useState("Farm 1")
  const [timeRange, setTimeRange] = useState("7d")
  const [waterEfficiency, setWaterEfficiency] = useState(75)

  // Mock data - in a real app, this would come from API calls to NASA data sources
  const mockWaterRiskData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      {
        label: "Drought Risk",
        data: [20, 30, 40, 50, 60, 55, 45],
        fill: true,
        backgroundColor: "rgba(255, 159, 64, 0.2)",
        borderColor: "rgb(255, 159, 64)",
      },
      {
        label: "Flood Risk",
        data: [10, 15, 20, 25, 30, 35, 40],
        fill: true,
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgb(54, 162, 235)",
      },
    ],
  }

  const mockSoilMoistureData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      {
        label: "Soil Moisture",
        data: [30, 35, 40, 38, 42, 45, 40],
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-green-900 dark:to-blue-900">
      <div className="container mx-auto p-4">
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-green-800 dark:text-green-200">Green Mile Dashboard</h1>
          <div className="flex items-center space-x-4">
            <Select value={location} onValueChange={setLocation}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select farm" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Farm 1">Farm 1</SelectItem>
                <SelectItem value="Farm 2">Farm 2</SelectItem>
                <SelectItem value="Farm 3">Farm 3</SelectItem>
              </SelectContent>
            </Select>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center text-2xl text-blue-700 dark:text-blue-300">
                <Droplets className="mr-2" />
                Water Risk Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AreaChart data={mockWaterRiskData} className="h-[300px]" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-2xl text-green-700 dark:text-green-300">
                <Leaf className="mr-2" />
                Water Efficiency
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center">
              <div className="text-6xl font-bold mb-4 text-green-600 dark:text-green-400">{waterEfficiency}%</div>
              <Progress value={waterEfficiency} className="w-full h-4" />
              <p className="mt-4 text-center text-gray-600 dark:text-gray-300">
                Your farm is using water efficiently. Keep up the good work!
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-2xl text-brown-700 dark:text-brown-300">
                <Sprout className="mr-2" />
                Soil Moisture Tracker
              </CardTitle>
            </CardHeader>
            <CardContent>
              <BarChart data={mockSoilMoistureData} className="h-[250px]" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-2xl text-yellow-700 dark:text-yellow-300">
                <Sun className="mr-2" />
                Weather Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="text-4xl font-bold">72°F</div>
                <Sun className="h-12 w-12 text-yellow-500" />
              </div>
              <p className="mb-2">Mostly sunny with a high of 75°F and a low of 62°F.</p>
              <p>Precipitation chance: 10%</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="tips" className="mb-8">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="tips">Water-Smart Tips</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
          </TabsList>
          <TabsContent value="tips">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-green-700 dark:text-green-300">Water Management Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <Leaf className="mr-2 text-green-500" />
                    Consider implementing drip irrigation to conserve water.
                  </li>
                  <li className="flex items-center">
                    <Droplets className="mr-2 text-blue-500" />
                    Based on soil moisture levels, delay irrigation for the next 2 days.
                  </li>
                  <li className="flex items-center">
                    <Sprout className="mr-2 text-brown-500" />
                    Mulch around plants to reduce evaporation.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="alerts">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-red-700 dark:text-red-300">Current Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center p-4 mb-4 text-yellow-800 bg-yellow-100 rounded-lg dark:bg-yellow-900 dark:text-yellow-300">
                  <AlertTriangle className="flex-shrink-0 w-5 h-5 mr-2" />
                  <span className="sr-only">Warning</span>
                  <div>
                    Potential drought conditions forecasted for next week. Consider adjusting irrigation schedules.
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center">
          <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white">
            <MapPin className="mr-2" />
            View Detailed Green Mile Maps
          </Button>
        </div>
      </div>
    </div>
  )
}